-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (1,'John Doe','johndoe@example.com'),(2,'Jane Smith','janesmith@example.com'),(3,'James Johnson','jamesjohnson@example.com'),(4,'Patricia Brown','patriciabrown@example.com'),(5,'Michael Williams','michaelwilliams@example.com'),(6,'Linda Jones','lindajones@example.com'),(7,'Robert Miller','robertmiller@example.com'),(8,'Barbara Davis','barbaradavis@example.com'),(9,'William Garcia','williamgarcia@example.com'),(10,'Elizabeth Martinez','elizabethmartinez@example.com'),(11,'David Wilson','davidwilson@example.com'),(12,'Jennifer Anderson','jenniferanderson@example.com'),(13,'Richard Thomas','richardthomas@example.com'),(14,'Maria Jackson','mariajackson@example.com'),(15,'Joseph White','josephwhite@example.com'),(16,'Susan Harris','susanharris@example.com'),(17,'Charles Clark','charlesclark@example.com'),(18,'Margaret Lewis','margaretlewis@example.com'),(19,'Thomas Robinson','thomasrobinson@example.com'),(20,'Dorothy Walker','dorothywalker@example.com'),(21,'Christopher Hall','christopherhall@example.com'),(22,'Nancy Young','nancyyoung@example.com'),(23,'Daniel Allen','danielallen@example.com'),(24,'Karen King','karenking@example.com'),(25,'Paul Wright','paulwright@example.com'),(26,'Betty Scott','bettyscott@example.com'),(27,'Mark Green','markgreen@example.com'),(28,'Helen Adams','helenadams@example.com'),(29,'George Baker','georgebaker@example.com'),(30,'Sandra Gonzalez','sandragonzalez@example.com'),(31,'Steven Nelson','stevennelson@example.com'),(32,'Donna Carter','donnacarter@example.com'),(33,'Kenneth Mitchell','kennethmitchell@example.com'),(34,'Ruth Perez','ruthperez@example.com'),(35,'Andrew Roberts','andrewroberts@example.com'),(36,'Sharon Turner','sharonturner@example.com'),(37,'Edward Phillips','edwardphillips@example.com'),(38,'Michelle Campbell','michellecampbell@example.com'),(39,'Brian Parker','brianparker@example.com'),(40,'Laura Evans','lauraevans@example.com'),(41,'Ronald Edwards','ronaldedwards@example.com'),(42,'Sarah Collins','sarahcollins@example.com'),(43,'Anthony Stewart','anthonystewart@example.com'),(44,'Kimberly Sanchez','kimberlysanchez@example.com'),(45,'Kevin Morris','kevinmorris@example.com'),(46,'Deborah Rogers','deborahrogers@example.com'),(47,'Jason Reed','jasonreed@example.com'),(48,'Jessica Cook','jessicacook@example.com'),(49,'Jeffrey Morgan','jeffreymorgan@example.com'),(50,'Dorothy Bell','dorothybell@example.com'),(51,'Gary Murphy','garymurphy@example.com'),(52,'Emily Bailey','emilybailey@example.com'),(53,'Ryan Rivera','ryanrivera@example.com'),(54,'Shirley Cooper','shirleycooper@example.com'),(55,'Jacob Richardson','jacobrichardson@example.com'),(56,'Cynthia Cox','cynthiacox@example.com'),(57,'Nicholas Howard','nicholashoward@example.com'),(58,'Rebecca Ward','rebeccaward@example.com'),(59,'Eric Torres','erictores@example.com'),(60,'Sharon Peterson','sharonpeterson@example.com'),(61,'Stephen Gray','stephengray@example.com'),(62,'Michelle Ramirez','michelleramirez@example.com'),(63,'Scott James','scottjames@example.com'),(64,'Amanda Watson','amandawatson@example.com'),(65,'Justin Brooks','justinbrooks@example.com'),(66,'Laura Kelly','laurakelly@example.com'),(67,'Brandon Sanders','brandonsanders@example.com'),(68,'Melissa Price','melissaprice@example.com'),(69,'Joshua Bennett','joshuabennett@example.com'),(70,'Angela Wood','angelawood@example.com'),(71,'Jonathan Barnes','jonathanbarnes@example.com'),(72,'Stephanie Ross','stephanieross@example.com'),(73,'Larry Henderson','larryhenderson@example.com'),(74,'Kelly Coleman','kellycoleman@example.com'),(75,'Jeffrey Jenkins','jeffreyjenkins@example.com'),(76,'Kathy Perry','kathyperry@example.com'),(77,'Frank Powell','frankpowell@example.com'),(78,'Amanda Long','amandalong@example.com'),(79,'Raymond Patterson','raymondpatterson@example.com'),(80,'Stephanie Hughes','stephaniehughes@example.com'),(81,'Gregory Flores','gregoryflores@example.com'),(82,'Rebecca Washington','rebeccawashington@example.com'),(83,'Jacob Butler','jacobbutler@example.com'),(84,'Shirley Simmons','shirleysimmons@example.com'),(85,'Jerry Foster','jerryfoster@example.com'),(86,'Dorothy Gonzales','dorothygonzales@example.com'),(87,'Patrick Bryant','patrickbryant@example.com'),(88,'Debra Alexander','debraalexander@example.com'),(89,'Harold Russell','haroldrussell@example.com'),(90,'Catherine Griffin','catherinegriffin@example.com'),(91,'Dennis Diaz','dennisdiaz@example.com'),(92,'Pamela Hayes','pamelahayes@example.com'),(93,'Jack Fisher','jackfisher@example.com'),(94,'Pamela Butler','pamelabutler@example.com');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-07  0:08:18
